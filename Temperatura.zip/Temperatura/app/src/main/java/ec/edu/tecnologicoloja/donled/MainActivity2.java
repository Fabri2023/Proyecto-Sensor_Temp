package ec.edu.tecnologicoloja.donled;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothGattCallback;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    boolean initHilo = false;
    boolean hilo = true;
    BluetoothJhr blue;
    String mensaje = "";
    TextView display;
    TermometroJhr termometroJhr;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        blue = new BluetoothJhr(this,DeviceListActivity.class);
        display = findViewById(R.id.display);
        termometroJhr = findViewById(R.id.termometroJhr);


        termometroJhr.tempMax(100);
        termometroJhr.tempMin(0);
        termometroJhr.setTimeAnimation(3000f);

        new